CREATE TABLE Especialidades (
    id_especialidad INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    descripcion TEXT
);

CREATE TABLE Diagnosticos (
    id_diagnostico INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    descripcion TEXT
);

CREATE TABLE Pacientes (
    id_paciente INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    apellido VARCHAR(100) NOT NULL,
    fecha_nacimiento DATE,
    sexo ENUM('M', 'F'),
    direccion VARCHAR(255),
    telefono VARCHAR(15),
    email VARCHAR(100)
);

CREATE TABLE Medicos (
    id_medico INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    apellido VARCHAR(100) NOT NULL,
    especialidad_id INT,
    telefono VARCHAR(15),
    email VARCHAR(100),
    FOREIGN KEY (especialidad_id) REFERENCES Especialidades(id_especialidad)
);

CREATE TABLE Atenciones (
    id_atencion INT AUTO_INCREMENT PRIMARY KEY,
    paciente_id INT NOT NULL,
    medico_id INT NOT NULL,
    especialidad_id INT NOT NULL,
    diagnostico_id INT NOT NULL,
    fecha_ingreso DATE NOT NULL,
    fecha_alta DATE,
    FOREIGN KEY (paciente_id) REFERENCES Pacientes(id_paciente),
    FOREIGN KEY (medico_id) REFERENCES Medicos(id_medico),
    FOREIGN KEY (especialidad_id) REFERENCES Especialidades(id_especialidad),
    FOREIGN KEY (diagnostico_id) REFERENCES Diagnosticos(id_diagnostico)
);
INSERT INTO Especialidades (nombre, descripcion) VALUES
('Cirugia', 'Descripción de Cirugía'),
('Pediatria', 'Descripción de Pediatría'),
('Medicina', 'Descripción de Medicina');

INSERT INTO Diagnosticos (nombre, descripcion) VALUES
('Ulceras', 'Descripción de Ulceras'),
('Bronquitis', 'Descripción de Bronquitis'),
('Hernia', 'Descripción de Hernia');

INSERT INTO Pacientes (nombre, apellido, fecha_nacimiento, sexo, direccion, telefono, email) VALUES
('Pedro', 'Peres', '1980-01-01', 'M', 'Dirección 1', '123456789', 'pedro.peres@example.com'),
('Carlos', 'Solar', '1990-02-02', 'M', 'Dirección 2', '234567890', 'carlos.solar@example.com'),
('Luis', 'Rojas', '1985-03-03', 'M', 'Dirección 3', '345678901', 'luis.rojas@example.com');

INSERT INTO Medicos (nombre, apellido, especialidad_id, telefono, email) VALUES
('Benjamin', 'Soto', 1, '456789012', 'benjamin.soto@example.com'),
('Eduardo', 'Cortes', 2, '567890123', 'eduardo.cortes@example.com'),
('Claudio', 'Gomez', 3, '678901234', 'claudio.gomez@example.com');

INSERT INTO Atenciones (paciente_id, medico_id, especialidad_id, diagnostico_id, fecha_ingreso, fecha_alta) VALUES
(1, 1, 1, 1, '2023-09-28', '2023-09-28'),
(2, 2, 2, 2, '2023-09-27', '2023-09-27'),
(3, 3, 3, 3, '2023-09-26', '2023-09-26');