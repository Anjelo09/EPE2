<?php
$mysqli = new mysqli('localhost', 'tu_usuario', 'tu_contraseña', 'nombre_de_tu_base_de_datos');

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}
?>

<?php
$mysqli = new mysqli('localhost', 'root', '', 'registro_atenciones');

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

$pacientes = $mysqli->query("SELECT id_paciente, nombre, apellido FROM Pacientes")->fetch_all(MYSQLI_ASSOC);
$medicos = $mysqli->query("SELECT id_medico, nombre, apellido FROM Medicos")->fetch_all(MYSQLI_ASSOC);
$especialidades = $mysqli->query("SELECT id_especialidad, nombre FROM Especialidades")->fetch_all(MYSQLI_ASSOC);
$diagnosticos = $mysqli->query("SELECT id_diagnostico, nombre FROM Diagnosticos")->fetch_all(MYSQLI_ASSOC);

echo json_encode([
    'pacientes' => $pacientes,
    'medicos' => $medicos,
    'especialidades' => $especialidades,
    'diagnosticos' => $diagnosticos
]);

$mysqli->close();
?>
