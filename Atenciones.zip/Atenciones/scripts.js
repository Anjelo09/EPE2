document.addEventListener("DOMContentLoaded", function() {
    cargarSelects();
});

function cargarSelects() {
    fetch('get_options.php')
        .then(response => response.json())
        .then(data => {
            const pacientes = data.pacientes;
            const medicos = data.medicos;
            const especialidades = data.especialidades;
            const diagnosticos = data.diagnosticos;

            const pacienteSelect = document.getElementById('paciente');
            pacientes.forEach(p => {
                const option = document.createElement('option');
                option.value = p.id_paciente;
                option.textContent = `${p.nombre} ${p.apellido}`;
                pacienteSelect.appendChild(option);
            });

            const medicoSelect = document.getElementById('medico');
            medicos.forEach(m => {
                const option = document.createElement('option');
                option.value = m.id_medico;
                option.textContent = `${m.nombre} ${m.apellido}`;
                medicoSelect.appendChild(option);
            });

            const especialidadSelect = document.getElementById('especialidad');
            especialidades.forEach(e => {
                const option = document.createElement('option');
                option.value = e.id_especialidad;
                option.textContent = e.nombre;
                especialidadSelect.appendChild(option);
            });

            const diagnosticoSelect = document.getElementById('diagnostico');
            diagnosticos.forEach(d => {
                const option = document.createElement('option');
                option.value = d.id_diagnostico;
                option.textContent = d.nombre;
                diagnosticoSelect.appendChild(option);
            });
        });
}

function guardarAtencion() {
    const formData = new FormData(document.getElementById('atencionForm'));
    fetch('guardar_atencion.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => alert(data));
}

function actualizarAtencion() {
    const formData = new FormData(document.getElementById('atencionForm'));
    fetch('actualizar_atencion.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => alert(data));
}

function eliminarAtencion() {
    const formData = new FormData(document.getElementById('atencionForm'));
    fetch('eliminar_atencion.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => alert(data));
}
