<?php
$mysqli = new mysqli('localhost', 'tu_usuario', 'tu_contraseña', 'nombre_de_tu_base_de_datos');

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}
?>

<?php
$mysqli = new mysqli('localhost', 'root', '', 'registro_atenciones');

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

$id_atencion = $_POST['id_atencion'];

$query = "DELETE FROM Atenciones WHERE id_atencion='$id_atencion'";

if ($mysqli->query($query)) {
    echo "Atención eliminada exitosamente.";
} else {
    echo "Error: " . $mysqli->error;
}

$mysqli->close();
?>
