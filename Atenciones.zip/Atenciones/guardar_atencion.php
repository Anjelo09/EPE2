<?php
$mysqli = new mysqli('localhost', 'tu_usuario', 'tu_contraseña', 'nombre_de_tu_base_de_datos');

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}
?>

<?php
$mysqli = new mysqli('localhost', 'root', '', 'registro_atenciones');

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

$paciente_id = $_POST['paciente_id'];
$medico_id = $_POST['medico_id'];
$especialidad_id = $_POST['especialidad_id'];
$diagnostico_id = $_POST['diagnostico_id'];
$fecha_ingreso = $_POST['fecha_ingreso'];
$fecha_alta = $_POST['fecha_alta'];

$query = "INSERT INTO Atenciones (paciente_id, medico_id, especialidad_id, diagnostico_id, fecha_ingreso, fecha_alta) 
          VALUES ('$paciente_id', '$medico_id', '$especialidad_id', '$diagnostico_id', '$fecha_ingreso', '$fecha_alta')";

if ($mysqli->query($query)) {
    echo "Atención guardada exitosamente.";
} else {
    echo "Error: " . $mysqli->error;
}

$mysqli->close();
?>
